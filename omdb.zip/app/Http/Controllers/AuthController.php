<?php

namespace App\Http\Controllers;

use App\Services\AuthService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    protected $authService;

    public function __construct(AuthService $authService)
    {
        $this->authService = $authService;
    }

    public function index()
    {
        return view('auth.login');
    }

    public function register()
    {
        return view('auth.register');
    }

    public function register_process(Request $request)
    {
        $validated = $request->validate(
            [
                'name' => ['required'],
                'email' => ['required', 'email', 'unique:users'],
                'password' => [
                    'required',
                    'confirmed',
                    Password::min(8),
                ],
            ],
            [
                'name.required' => __('validation.required', [
                    'attribute' => __('regis.full_name')
                ]),

                'email.required' => __('validation.required', [
                    'attribute' => __('regis.email')
                ]),

                'email.email' => __('validation.email', [
                    'attribute' => __('regis.email')
                ]),

                'email.unique' => __('validation.unique', [
                    'attribute' => __('regis.email')
                ]),

                'password.required' => __('validation.required', [
                    'attribute' => __('regis.password')
                ]),

                'password.confirmed' => __('validation.confirmed', [
                    'attribute' => __('regis.password')
                ]),
            ]
        );

        try {
            $response = $this->authService->register($validated);

            if (! $response) {
                return redirect()->back()->with('error', __('regis.register_failed'));
            }

            return redirect()->route('login')->with('success', __('regis.register_success'));

        } catch (\Throwable $th) {
            Log::error([
                'line' => $th->getLine(),
                'file' => $th->getFile(),
                'message' => $th->getMessage()
            ]);

            return redirect()->back()->with('error', __('regis.error'));
        }
    }

    public function login(Request $request)
    {
        $validated = $request->validate(
            [
                'email' => ['required', 'email', 'exists:users'],
                'password' => ['required'],
            ],
            [
                'email.required' => __('validation.required', [
                    'attribute' => __('auth.email')
                ]),

                'email.email' => __('validation.email', [
                    'attribute' => __('auth.email')
                ]),

                'email.exists' => __('validation.exists', [
                    'attribute' => __('auth.email')
                ]),

                'password.required' => __('validation.required', [
                    'attribute' => __('auth.password')
                ]),
            ]
        );

        try {
            $response = $this->authService->login($validated);

            if (! $response) {
                return redirect()->back()->with('error', __('auth.invalid_credentials'));
            }

            session(['logged_in' => true]);

            return redirect()->route('dashboard')
                ->with('success', __('auth.login_success'));

        } catch (\Throwable $th) {
            Log::error([
                'line' => $th->getLine(),
                'file' => $th->getFile(),
                'message' => $th->getMessage(),
            ]);

            return redirect()->back()->with('error', __('auth.error'));
        }
    }
    public function logout()
    {
        try {
            session()->flush();
            return redirect('/')->with('success', 'Anda telah keluar');
        } catch (\Throwable $th) {
            Log::error([
                'line'      => $th->getLine(),
            'file'      => $th->getFile(),
            'message'   => $th->getMessage(),
        ]);

            return redirect()->back()->with('error', 'Terjadi kesalahan');
        }
    }
public function signout()
{
    session()->flush();

    return redirect('http://127.0.0.1:8000')
        ->withCookie(cookie()->forget(config('session.cookie')));
}
public function changeLanguage($locale)
{
    if (in_array($locale, ['id', 'en'])) {
        session(['locale' => $locale]);
    }

    return redirect()->back();
}
}
