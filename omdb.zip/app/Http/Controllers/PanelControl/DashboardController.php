<?php

namespace App\Http\Controllers\PanelControl;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        return view('panel_control.dashboard');
    }
    public function my()
{
    return view('panel_control.my');
}       

}
